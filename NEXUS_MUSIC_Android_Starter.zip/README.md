# NEXUS MUSIC — Android starter project

Protótipo Android em Kotlin com WebView e interface neon azul.

## O que esta versão faz
- Mostra a interface NEXUS MUSIC.
- Abre pesquisa de músicas no YouTube oficial.
- Incorpora um vídeo do YouTube quando o usuário fornece um link ou ID.
- Mantém o player e seus controles oficiais.

## Limitações desta versão
- Ainda não inclui biblioteca local/offline, playlists persistentes ou equalizador de áudio real.
- O visualizador é decorativo, não uma análise do áudio.
- A pesquisa abre os resultados do YouTube; não é uma pesquisa de catálogo dentro do app.
- O player exige internet e pode não permitir reprodução em segundo plano. Não contorna anúncios, restrições ou regras do YouTube.
- Para pesquisar resultados dentro do próprio app, planeje uma integração com YouTube Data API v3 e uma chave de API; proteja e restrinja a chave adequadamente.

## Abrir no Android Studio
1. Extraia o ZIP.
2. No Android Studio, escolha **Open** e selecione a pasta `NexusMusicAndroid`.
3. Aguarde a sincronização do Gradle e instale os componentes de SDK sugeridos.
4. Conecte seu Android com depuração USB ativada ou inicie um emulador.
5. Pressione **Run** para testar.

## Gerar APK de teste
No Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O APK de depuração normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

Ou, no terminal da raiz do projeto, com Gradle instalado/configurado:
`gradle :app:assembleDebug`

Para publicar ou distribuir uma versão de lançamento, configure assinatura própria em **Build > Generate Signed Bundle / APK**. Não compartilhe a chave privada.

## Próximas etapas
1. Biblioteca de arquivos locais usando Android Storage Access Framework/MediaStore.
2. Playlists persistentes e capas/metadados.
3. Equalizador usando APIs Android suportadas pelo dispositivo.
4. Pesquisa integrada via YouTube Data API v3, se desejado.

## Compilar sem computador (GitHub Actions)
Este projeto inclui `.github/workflows/build-apk.yml` para tentar compilar o APK na nuvem.
1. No navegador do celular, crie uma conta no GitHub, se ainda não tiver.
2. Crie um repositório novo e envie os arquivos/pastas deste ZIP (incluindo a pasta oculta `.github`).
3. Abra a aba **Actions**, selecione **Build NEXUS MUSIC APK** e toque em **Run workflow**.
4. Quando terminar com sucesso, abra a execução e baixe **nexus-music-debug-apk** na seção Artifacts.
5. Extraia o ZIP baixado e instale `app-debug.apk`. O Android pode pedir autorização para instalar apps dessa origem.

A compilação na nuvem é uma alternativa; não foi executada/verificada nesta conversa.
